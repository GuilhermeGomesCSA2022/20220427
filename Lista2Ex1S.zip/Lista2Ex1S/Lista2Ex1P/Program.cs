﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex1P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;

            Console.Write("Digite o primeiro valor: ");
            n1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o segundo valor: ");
            n2 = double.Parse(Console.ReadLine());

            if (n1 > n2)
            {
                Console.WriteLine("O primeiro é o maior");
            }
            else 
            {
                Console.WriteLine("O segundo valor é o maior");
            }
        }
    }
}
