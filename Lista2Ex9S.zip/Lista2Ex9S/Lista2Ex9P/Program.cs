﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex9P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string sexo;
            double h;
            double p;
            double relacao;

            Console.Write("Digite o Peso em Kg: ");
            p = double.Parse(Console.ReadLine());

            Console.Write("Informe o Sexo do Individuo -> (M)asculino ou (F)eminino: ");
            sexo = Console.ReadLine();

            Console.Write("Digite a Altura em m: ");
            h = double.Parse(Console.ReadLine());

            relacao = p / Math.Pow(h, 2);

            if (sexo=="m")
            {
                if (relacao < 20)
                {
                    Console.WriteLine("Abaixo do Peso");
                }
                else
                {
                    if (relacao < 25)
                    {
                        Console.WriteLine("Peso Ideal");
                    }
                    else
                    {
                        Console.WriteLine("Acima do Peso");
                    }
                }
            }
            if (sexo== "f"  )
            {
                if (relacao < 19)
                {
                    Console.WriteLine("Abaixo do Peso");
                }
                else
                {
                    if (relacao < 24)
                    {
                        Console.WriteLine("Peso Ideal");
                    }
                    else
                    {
                        Console.WriteLine("Acima do Peso");
                    }
                }
            }


        }
       }
    }


