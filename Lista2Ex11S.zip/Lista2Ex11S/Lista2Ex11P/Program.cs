﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex11P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double np1;
            double np2;

            Console.Write("Digite o valor da primeira prova: ");
            np1 = double.Parse(Console.ReadLine());

            np2 = (15 - (np1)) / 2;

            Console.WriteLine("Para ser aprovado o aluno necessita de pelo menos {0:f1} na segunda prova, para ser aprovado", np2);
        }
    }
}
