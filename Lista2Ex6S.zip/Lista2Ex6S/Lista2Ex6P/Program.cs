﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex6P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso;
            double h;
            double relacao;

            Console.Write("Digite o valor do peso em Kg: ");
            peso = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura em m: ");
            h = double.Parse(Console.ReadLine());

            relacao = peso / (Math.Pow(h, 2));

            if (relacao < 20)
            {
                Console.WriteLine("Abaixo do Peso");
            }
            else
            {
                if (relacao < 25)
                {
                    Console.WriteLine("Peso ideal");
                }
                else 
                {
                    Console.WriteLine("Acima do peso");
                }
            }



        }
    }
}
